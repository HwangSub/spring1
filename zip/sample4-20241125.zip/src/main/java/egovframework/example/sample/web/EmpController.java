package egovframework.example.sample.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.example.sample.service.EmpService;
import egovframework.example.sample.service.EmpVO;

@Controller
public class EmpController {

	@Resource(name="empService")
	EmpService empService;
	
	@RequestMapping(value="/empList.do")
	public String selectEmpList(ModelMap model) throws Exception {
		
		int total    = empService.selectEmpTotal();
		
		// 17/10 -> 1.7 -> ceil(1.7) -> 2.0 -> (int)2.0 -> 2
		int totalpage= (int)Math.ceil((double)total/10);
		
		List<?> list = empService.selectEmpList();
		
		model.addAttribute("emplist", list);
		model.addAttribute("total", total);
		model.addAttribute("totalpage", totalpage);

		return "emp/empList";
	}
	
	@RequestMapping(value="/empWrite.do")
	public String empWrite() throws Exception {
		
		return "emp/empWrite";
	}
	
	@RequestMapping(value="/empSave.do")
	public String insertEmp(EmpVO vo) throws Exception {	
		int result = empService.insertEmp(vo);
		if( result == 1 ) {
			System.out.println("저장결과:성공");
		} else {
			System.out.println("저장결과:실패");
		}
		return "redirect:/empList.do";
	}
	
}




