package egovframework.example.sample.service.impl;

import java.util.List;
import org.egovframe.rte.psl.dataaccess.mapper.Mapper;
import egovframework.example.sample.service.EmpVO;

@Mapper("empMapper")
public interface EmpMapper {
	List<?> selectEmpList();
	int selectEmpTotal();
	int insertEmp(EmpVO vo);
}
