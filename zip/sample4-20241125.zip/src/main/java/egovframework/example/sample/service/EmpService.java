package egovframework.example.sample.service;

import java.util.List;

public interface EmpService {
	
	/*
	 * 사원목록 출력
	 */
	List<?> selectEmpList() throws Exception;

	/*
	 * 사원등록 개수
	 */
	int selectEmpTotal() throws Exception;
	
	/*
	 * 사원정보 등록
	 */
	int insertEmp(EmpVO vo) throws Exception; 
	
	
}





